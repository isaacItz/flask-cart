import pymysql

def MySQLConn():
    return pymysql.connect(host='localhost', user='root', password='', db='comicon')
